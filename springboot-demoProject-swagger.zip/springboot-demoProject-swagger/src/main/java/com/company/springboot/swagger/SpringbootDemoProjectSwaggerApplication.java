package com.company.springboot.swagger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDemoProjectSwaggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDemoProjectSwaggerApplication.class, args);
	}
}
